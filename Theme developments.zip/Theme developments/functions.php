<?php
/*
fast use for theme. add support.
*/
function meal_set_up_theme(){
    load_theme_textdomain( 'meal',get_template_directory(  )."/languages" );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'title-tags' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'html5',array(
        'search-from',
        'comment-from',
        'gallery',
        'caption',
        'connent-list'
    ));
    add_theme_support( 'custom-logo' );
}
add_action( 'after_setup_theme','meal_set_up_theme' );
/*
 add enqueue.
*/
function meal_assets() {
    wp_enqueue_style( 'meal-fonts', '//fonts.googleapis.com/css?family=Playfair+Display:300,400,700,800|Open+Sans:300,400,700"' );
    wp_enqueue_style( 'bootstrap-css', get_template_directory_uri() . '/assets/css/bootstrap.css', null,'1.0' );
    wp_enqueue_style( 'meal-style', get_stylesheet_uri() );

    wp_enqueue_script( 'popper-js', get_template_directory_uri() . '/assets/js/popper.min.js', array( 'jquery' ),'1.0', true );
    wp_enqueue_script('google-map-js','//maps.googleapis.com/maps/api/js?key=AIzaSyAi7R75-IIp5bzlbNoowhoW0LBqAi3I7nM',null,'1.0',true);

}
add_action( 'wp_enqueue_scripts', 'meal_assets' );

/*
Cheack for get_stylesheet_uri().
*/
die(site_url());
////////////
if(site_url(  )=='http://localhost/development'){
    define('VERSION',time());
}else{
    define('VERSION',wp_get_theme( )->get('Version'));
}
///example.....
wp_enqueue_style('stylesheet',get_stylesheet_uri(  ),null,VERSION
);
